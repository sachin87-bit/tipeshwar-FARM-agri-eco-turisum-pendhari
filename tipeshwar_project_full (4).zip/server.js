require('dotenv').config();
const express = require('express');
const fetch = (...args) => import('node-fetch').then(({default:fetch})=>fetch(...args));
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const GOOGLE_API_KEY = process.env.GOOGLE_API_KEY;

if (!GOOGLE_API_KEY) {
  console.error('ERROR: Set GOOGLE_API_KEY in environment');
  process.exit(1);
}

app.use(helmet());
app.use(cors({ origin: process.env.ALLOWED_ORIGIN || '*' }));
app.use(bodyParser.json({ limit: '2mb' }));

const apiLimiter = rateLimit({ windowMs: 60*1000, max: 30, message: { error: 'Too many requests' } });
app.use('/api/', apiLimiter);

async function callGoogleGenerate(contents) {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-09-2025:generateContent?key=${GOOGLE_API_KEY}`;
  const resp = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ contents }) });
  if (!resp.ok) {
    const txt = await resp.text();
    const e = new Error(`Google API error ${resp.status}: ${txt}`);
    e.status = resp.status;
    throw e;
  }
  return resp.json();
}

app.post('/api/generate', async (req, res) => {
  try {
    const { prompt, options = {} } = req.body;
    if (!prompt || typeof prompt !== 'string') return res.status(400).json({ error: 'Missing prompt' });
    if (prompt.length > 4000) return res.status(400).json({ error: 'Prompt too long' });

    const parts = [{ text: prompt }];
    const contents = [{ parts }];
    const data = await callGoogleGenerate(contents);
    const candidateText = data?.candidates?.[0]?.content?.parts?.[0]?.text;
    if (!candidateText) return res.status(502).json({ error: 'No text from LLM' });
    res.json({ text: candidateText });
  } catch (err) {
    console.error('generate error', err);
    res.status(err.status || 500).json({ error: 'Server error calling LLM' });
  }
});

app.post('/api/identify-wildlife', async (req, res) => {
  try {
    const { desc = '', imageBase64 = null } = req.body;
    if (!desc && !imageBase64) return res.status(400).json({ error: 'Provide desc or imageBase64' });
    if (imageBase64 && imageBase64.length > 2_000_000) return res.status(413).json({ error: 'Image too large' });

    const promptText = imageBase64
      ? `Identify animal/bird in the provided image. Likely Tipeshwar region. Give Marathi name and 1-2 short facts.`
      : `Identify animal/bird from this description: "${desc}". Likely Tipeshwar region. Give Marathi name and 1-2 short facts.`;

    const parts = [{ text: promptText }];
    if (imageBase64) parts.push({ inlineData: { mimeType: "image/jpeg", data: imageBase64 } });
    const contents = [{ parts }];
    const data = await callGoogleGenerate(contents);
    const candidateText = data?.candidates?.[0]?.content?.parts?.[0]?.text;
    if (!candidateText) return res.status(502).json({ error: 'No text from LLM' });
    res.json({ text: candidateText });
  } catch (err) {
    console.error('identify-wildlife error', err);
    res.status(err.status || 500).json({ error: 'Server error calling LLM' });
  }
});

app.get('/api/health', (req, res) => res.json({ ok: true, env: process.env.NODE_ENV || 'development' }));

// Serve client
app.use(express.static(path.join(__dirname, 'public')));
app.get('/', (req,res) => res.sendFile(path.join(__dirname,'public','index.html')));

app.listen(PORT, () => console.log(`Tipeshwar AI proxy listening on port ${PORT}`));
