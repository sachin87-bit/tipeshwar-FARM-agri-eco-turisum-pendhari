Tipeshwar — Full Client + Node Proxy (Dockerized)

What's included
- public/index.html : full client you provided
- server.js          : Express proxy that calls Google Generative Language API
- package.json
- .env.example
- Dockerfile
- docker-compose.yml

Setup (local)
1. Copy .env.example to .env and set GOOGLE_API_KEY and ALLOWED_ORIGIN.
2. Install dependencies and run:
   npm install
   npm run dev   # for development with nodemon
   or
   npm start     # production

Docker (build & run)
1. Build:
   docker build -t tipeshwar-proxy .
2. Run:
   docker run -e GOOGLE_API_KEY=... -e ALLOWED_ORIGIN=http://localhost:3000 -p 3000:3000 tipeshwar-proxy

Using docker-compose
1. Create a .env file with GOOGLE_API_KEY and ALLOWED_ORIGIN.
2. Run:
   docker-compose up --build

Security notes
- Never store GOOGLE_API_KEY in client code.
- Use rate limiting (already included) to protect quota.
- Sanitize all outputs on the client (DOMPurify included in client).
